package action;

import entity.Entity;

/** A combat choice that can be shown in a menu and executed. */
public interface Action {
    public void execute(Entity source, Entity target);
    public int getAPCost();
    public String getName();
    public String getDescription();
}
