package action.concrete;

import action.Attack;
import entity.Entity;

/** A standard 1 AP attack. */
public class BasicAttack extends Attack {
    public BasicAttack() {
        super("Basic Attack", "Deal damage equal to effective Attack.", 1);
    }
    public int getAttackValue(Entity source) {
        return source.getEffectiveAttack();
    }
}
