package action.concrete;

import action.Attack;
import entity.Entity;

/** The Archer's stronger ranged attack. */
public class AimedShot extends Attack {
    public AimedShot() {
        super("Aimed Shot", "Deal effective Attack plus 5 damage.", 2);
    }
    public int getAttackValue(Entity source) {
        return source.getEffectiveAttack() + 5;
    }
}
