package action.concrete;

import action.Buff;
import entity.Entity;

/** An enemy Buff that permanently adds Attack and stacks during combat. */
public class Rage extends Buff {
    public Rage() {
        super("Rage", "Gain +2 Attack for this battle.",
                Integer.MAX_VALUE);
    }
    public void execute(Entity source, Entity target) {
        source.addBuff(new Rage());
    }
    public int getAttackModifier() {
        return 2;
    }
}
