package action.concrete;

import action.Defend;
import entity.Entity;

/** Converts effective Defense into temporary Block. */
public class ShieldBlock extends Defend {
    public ShieldBlock() {
        super("Shield Block", "Gain Block equal to effective Defense.", 1);
    }
    public int getBlockValue(Entity source) {
        return source.getEffectiveDefense();
    }
}
