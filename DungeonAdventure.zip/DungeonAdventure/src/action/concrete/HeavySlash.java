package action.concrete;

import action.Attack;
import entity.Entity;

/** A stronger attack used by Warriors and more dangerous enemies. */
public class HeavySlash extends Attack {
    public HeavySlash() {
        super("Heavy Slash", "Deal effective Attack plus 5 damage.", 2);
    }
    public int getAttackValue(Entity source) {
        return source.getEffectiveAttack() + 5;
    }
}
