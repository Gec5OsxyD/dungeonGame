package action.concrete;

import action.Buff;

/** A battle-long buff that adds one Attack. */
public class Focus extends Buff {
    public Focus() {
        super("Focus", "Gain +2 Attack for this battle.", Integer.MAX_VALUE);
    }
    public int getAttackModifier() {
        return 2;
    }
}
