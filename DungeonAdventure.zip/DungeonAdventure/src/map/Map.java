package map;

import entity.Boss;
import entity.Monster;
import map.node.BossNode;
import map.node.CampfireNode;
import map.node.EventNode;
import map.node.MapNode;
import map.node.MonsterNode;
import map.node.ShopNode;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class Map {
    private static final int ROUTE_COUNT = 3;
    private static final int ROUTE_LENGTH = 8;

    private MapNode[][] routes;
    private MapNode[] nodes;
    private int currentNodeIndex;
    private String mapFileName;
    private Scanner console;
    private Random random;

    public enum NodeType {
        MONSTER, EVENT, CAMPFIRE, SHOP, BOSS
    }

    public Map(Scanner console) {
        this(console, new Random());
    }
    public Map(Scanner console, Random random) {
        routes = new MapNode[ROUTE_COUNT][];
        nodes = null;
        currentNodeIndex = 0;
        mapFileName = "dungeonMap.txt";
        this.console = console;
        this.random = random;
    }
    public void setConsole(Scanner console) {
        this.console = console;
    }
    public void generateMap() throws IOException {
        Set<String> routeSignatures = new HashSet<String>();
        for (int routeIndex = 0; routeIndex < ROUTE_COUNT; routeIndex++) {
            NodeType[] routeTypes;
            String signature;
            do {
                routeTypes = generateRouteTypes();
                signature = createSignature(routeTypes);
            } while (routeSignatures.contains(signature));

            routeSignatures.add(signature);
            routes[routeIndex] = createRoute(routeTypes);
        }
    }
    public NodeType[] generateRouteTypes() {
        NodeType[] routeTypes = new NodeType[ROUTE_LENGTH];
        routeTypes[0] = NodeType.MONSTER;
        routeTypes[ROUTE_LENGTH - 2] = NodeType.CAMPFIRE;
        routeTypes[ROUTE_LENGTH - 1] = NodeType.BOSS;

        List<NodeType> middleNodes = new ArrayList<NodeType>();
        middleNodes.add(NodeType.MONSTER);
        middleNodes.add(NodeType.EVENT);
        middleNodes.add(NodeType.SHOP);

        NodeType[] extraOptions = {
            NodeType.MONSTER, NodeType.EVENT, NodeType.CAMPFIRE
        };
        middleNodes.add(extraOptions[random.nextInt(extraOptions.length)]);
        middleNodes.add(extraOptions[random.nextInt(extraOptions.length)]);
        Collections.shuffle(middleNodes, random);

        for (int i = 0; i < middleNodes.size(); i++) {
            routeTypes[i + 1] = middleNodes.get(i);
        }
        return routeTypes;
    }
    public String createSignature(NodeType[] routeTypes) {
        String signature = "";
        for (NodeType type : routeTypes) {
            signature += type.name() + "-";
        }
        return signature;
    }
    public MapNode[] createRoute(NodeType[] routeTypes) {
        MapNode[] route = new MapNode[ROUTE_LENGTH];
        int monsterNumber = 0;
        for (int nodeIndex = 0; nodeIndex < routeTypes.length; nodeIndex++) {
            NodeType type = routeTypes[nodeIndex];
            if (type == NodeType.MONSTER) {
                monsterNumber++;
                route[nodeIndex] = createMonsterNode(nodeIndex, monsterNumber);
            } else if (type == NodeType.EVENT) {
                route[nodeIndex] = new EventNode(nodeIndex, console, random);
            } else if (type == NodeType.CAMPFIRE) {
                route[nodeIndex] = new CampfireNode(nodeIndex, console);
            } else if (type == NodeType.SHOP) {
                route[nodeIndex] = new ShopNode(nodeIndex, console);
            } else {
                route[nodeIndex] = new BossNode(nodeIndex,
                        new Boss("Guardian", "boss", 60, 9, 3), console, random);
            }
        }
        return route;
    }
    public MonsterNode createMonsterNode(int nodeId, int monsterNumber) {
        Monster monster;
        if (monsterNumber == 1) {
            monster = new Monster("Slime", "Slime", "monster1", 20, 5, 0);
        } else if (monsterNumber == 2) {
            monster = new Monster("Goblin", "Goblin", "monster2", 30, 7, 1);
        } else {
            monster = new Monster("Ogre", "Ogre", "monster3", 40, 9, 2);
        }
        return new MonsterNode(nodeId, monster, console, random);
    }
    public void displayRouteChoices() {
        System.out.println("\nA map appears in your hands.");
        System.out.println("Seems there are three paths before you:");
        for (int routeIndex = 0; routeIndex < routes.length; routeIndex++) {
            System.out.println("[" + (routeIndex + 1) + "] "
                    + routeDescription(routes[routeIndex]));
        }
        System.out.println();
    }
    public void selectRoute(int routeNumber) throws IOException {
        if (routeNumber < 1 || routeNumber > ROUTE_COUNT) {
            throw new IllegalArgumentException("Route must be from 1 to " + ROUTE_COUNT + ".");
        }
        nodes = routes[routeNumber - 1];
        currentNodeIndex = 0;
        saveMap();
    }
    public String routeDescription(MapNode[] route) {
        String description = "";
        for (int i = 0; i < route.length; i++) {
            if (i > 0) {
                description += " --> ";
            }
            description += nodeTypeName(route[i]);
        }
        return description;
    }
    public String nodeTypeName(MapNode node) {
        if (node instanceof MonsterNode) {
            return "Monster";
        } else if (node instanceof EventNode) {
            return "? ? ?";
        } else if (node instanceof CampfireNode) {
            return "Campfire";
        } else if (node instanceof ShopNode) {
            return "Shop";
        }
        return "Boss";
    }
    public boolean travelToNextNode() {
        if (hasNextNode()) {
            currentNodeIndex++;
            return true;
        }
        return false;
    }
    public MapNode getCurrentNode() {
        return nodes[currentNodeIndex];
    }
    public void markCurrentNodeVisited() {
        nodes[currentNodeIndex].markVisited();
    }
    public void saveMap() throws IOException {
        if (nodes == null) {
            return;
        }
        PrintStream out = new PrintStream(new File(mapFileName));
        for (MapNode node : nodes) {
            if (node.isVisited()) {
                out.print(" --> [X]");
            } else {
                out.print(" --> " + node);
            }
        }
        out.println();
        out.close();
    }
    public void updateMap() throws IOException {
        saveMap();
    }
    public Scanner loadMap() throws FileNotFoundException {
        return new Scanner(new File(mapFileName));
    }
    public void displayMap() throws FileNotFoundException {
        Scanner fileScanner = loadMap();
        while (fileScanner.hasNextLine()) {
            System.out.println(fileScanner.nextLine());
        }
        fileScanner.close();
    }
    public boolean hasNextNode() {
        return currentNodeIndex < nodes.length - 1;
    }
    public boolean isComplete() {
        return currentNodeIndex == nodes.length - 1;
    }
}
