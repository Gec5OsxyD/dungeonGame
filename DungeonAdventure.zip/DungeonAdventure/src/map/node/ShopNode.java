package map.node;

import entity.Player;
import event.Shop;

import java.util.Scanner;

public class ShopNode extends MapNode {
    private Shop shop;

    public ShopNode(int nodeId, Scanner console) {
        super(nodeId);
        shop = new Shop(console);
    }
    public void enter(Player player) {
        shop.execute(player);
    }
    public String toString() {
        return "[Shop]";
    }
}
