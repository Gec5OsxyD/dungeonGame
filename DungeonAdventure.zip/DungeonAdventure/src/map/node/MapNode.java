package map.node;

import entity.Player;

public abstract class MapNode {
    private int nodeId;
    private boolean visited;

    public MapNode(int nodeId) {
        this.nodeId = nodeId;
        this.visited = false;
    }
    public abstract void enter(Player player);
    public void markVisited() {
        visited = true;
    }
    public boolean isVisited() {
        return visited;
    }
    public int getNodeId() {
        return nodeId;
    }
}
