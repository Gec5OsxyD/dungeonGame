package entity;

import action.concrete.BasicAttack;
import action.concrete.Focus;
import action.concrete.ShieldBlock;
import action.concrete.Vulnerable;

public class Mage extends Player {
    private int mageEffectLimit = 3;

    public Mage() {
        super(24, 5, 1);
        initializeActions();
        giveStarterItems("Starter Wand");
    }
    public void initializeActions() {
        addAction(new BasicAttack());
        addAction(new ShieldBlock());
        addAction(new Focus());
        addAction(new Vulnerable());
    }
    public boolean canUseBuff() {
        return getBuffsUsed() < mageEffectLimit;
    }
    public boolean canUseDebuff() {
        return getDebuffsUsed() < mageEffectLimit;
    }
}
