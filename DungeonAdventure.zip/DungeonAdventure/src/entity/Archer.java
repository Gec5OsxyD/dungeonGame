package entity;

import action.concrete.AimedShot;
import action.concrete.QuickShot;
import action.concrete.ShieldBlock;

/** Offensive class with the design document's Archer statistics. */
public class Archer extends Player {
    public Archer() {
        super(26, 6, 1);
        initializeActions();
        giveStarterItems("Starter Bow");
    }
    public void initializeActions() {
        addAction(new QuickShot());
        addAction(new AimedShot());
        addAction(new ShieldBlock());
    }
}
