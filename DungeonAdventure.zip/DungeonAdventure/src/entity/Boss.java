package entity;

import action.concrete.BasicAttack;
import action.concrete.HeavySlash;
import action.concrete.Rage;
import action.concrete.ShieldBlock;
import action.concrete.Vulnerable;

/** Final enemy with a stronger repeating pattern. */
public class Boss extends Enemy {
    private final String lootTableId;

    public Boss(String name, String lootTableId, int hp, int attack, int defense) {
        super(name, hp, attack, defense);
        this.lootTableId = lootTableId;
        finishInitialization();
    }
    public void initializeActions() {
        addAction(new Rage());
        addAction(new BasicAttack());
        addAction(new Vulnerable());
        addAction(new HeavySlash());
        addAction(new ShieldBlock());
        addAction(new HeavySlash());
    }
    public String getLootTableId() {
        return lootTableId;
    }
}
