package entity;

import action.concrete.BasicAttack;
import action.concrete.HeavySlash;
import action.concrete.Rage;
import action.concrete.ShieldBlock;

/** A normal dungeon enemy with a pattern based on its monster type. */
public class Monster extends Enemy {
    private String monsterId;
    private String lootTableId;

    public Monster(String monsterId, String name, String lootTableId,
            int hp, int attack, int defense) {
        super(name, hp, attack, defense);
        this.monsterId = monsterId;
        this.lootTableId = lootTableId;
        finishInitialization();
    }
    public void initializeActions() {
        if ("Slime".equals(monsterId)) {
            addAction(new BasicAttack());
            addAction(new BasicAttack());
            addAction(new ShieldBlock());
        } else if ("Goblin".equals(monsterId)) {
            addAction(new HeavySlash());
            addAction(new BasicAttack());
            addAction(new ShieldBlock());
        } else {
            addAction(new Rage());
            addAction(new HeavySlash());
            addAction(new BasicAttack());
            addAction(new ShieldBlock());
        }
    }
    public String getMonsterId() {
        return monsterId;
    }
    public String getLootTableId() {
        return lootTableId;
    }
}
