package entity;

import action.concrete.BasicAttack;
import action.concrete.HeavySlash;
import action.concrete.ShieldBlock;

public class Warrior extends Player {
    public Warrior() {
        super(32, 5, 2);
        initializeActions();
        giveStarterItems("Starter Sword");
    }
    public void initializeActions() {
        addAction(new BasicAttack());
        addAction(new HeavySlash());
        addAction(new ShieldBlock());
    }
}
