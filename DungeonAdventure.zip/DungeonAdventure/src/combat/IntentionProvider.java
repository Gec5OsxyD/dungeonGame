package combat;

import entity.Enemy;
import entity.Entity;

/** Strategy used to choose an enemy's next announced action. */
public interface IntentionProvider {
    public EnemyIntention determineNextAction(Enemy enemy, Entity target);
}
