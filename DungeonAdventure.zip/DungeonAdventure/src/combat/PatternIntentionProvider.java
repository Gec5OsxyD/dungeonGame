package combat;

import java.util.ArrayList;
import java.util.List;

import action.Action;
import action.Attack;
import action.Buff;
import action.Defend;
import entity.Enemy;
import entity.Entity;

/** Cycles through a fixed action list. */
public class PatternIntentionProvider implements IntentionProvider {
    private List<Action> actionPattern;
    private int currentIndex;

    public PatternIntentionProvider(List<Action> actionPattern) {
        this.actionPattern = new ArrayList<Action>(actionPattern);
    }
    public EnemyIntention determineNextAction(Enemy enemy, Entity target) {
        Action action = actionPattern.get(currentIndex);
        currentIndex = (currentIndex + 1) % actionPattern.size();
        int expectedValue = 0;
        if (action instanceof Attack) {
            expectedValue = ((Attack) action).getAttackValue(enemy);
        } else if (action instanceof Defend) {
            expectedValue = ((Defend) action).getBlockValue(enemy);
        } else if (action instanceof Buff) {
            expectedValue = ((Buff) action).getAttackModifier();
        }
        return new EnemyIntention(action, action.getDescription(), expectedValue);
    }
}
