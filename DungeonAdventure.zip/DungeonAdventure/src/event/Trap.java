package event;

import java.util.Scanner;

import entity.Player;

/** Deals 7 unavoidable damage and awards 12 gold. */
public class Trap extends Event {
    public Trap(Scanner console) {
        super(console);
    }
    public void execute(Player player) {
        player.takeRawDamage(7);
        player.addGold(12);
        System.out.println("A trap hits you for 7 damage, but you find 12 gold.");
        System.out.println("HP: " + player.getHp() + "/" + player.getMaxHp());
    }
}
