package event;

import java.util.Scanner;

import entity.Player;

/** Base type for non-combat dungeon events. */
public abstract class Event {
    public Scanner console;
    public Event(Scanner console) {
        this.console = console;
    }
    public abstract void execute(Player player);
}
